//
//  jindutiao.h
//  DICOMViewer
//
//  Created by 李春菲 on 17/5/22.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jindutiao : UIView
@property (weak, nonatomic) IBOutlet UIProgressView *progressview;

@end
