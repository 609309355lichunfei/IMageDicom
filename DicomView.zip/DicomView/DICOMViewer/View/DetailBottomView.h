//
//  DetailBottomView.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/31.
//  Copyright © 2017年 ZJQ. All rights reserved.
//



#import <UIKit/UIKit.h>




@protocol DetailBottomViewDelegate <NSObject>

- (void)mesureWithAnnotationType:(NSInteger)annotationType;
- (void)removeCanvasView;

@end

@class KSDicom2DView,KSDicomDecoder,CanvasView;
@interface DetailBottomView : UIView


@property (nonatomic, strong) KSDicom2DView           *            dicom2DView;
@property (nonatomic, strong) KSDicomDecoder          *            dicomDecoder;


/**
 判断是否是标注，因为在标注和非标注的情况下，所展示的subViews是不同的，所以需要进行判断
 */
@property (nonatomic, assign) BOOL                                 isAnnotation;

@property (nonatomic, weak) id <DetailBottomViewDelegate>          delegate;

@end
