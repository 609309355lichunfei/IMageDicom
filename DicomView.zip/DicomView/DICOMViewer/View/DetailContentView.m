//
//  DetailContentView.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/31.
//  Copyright © 2017年 ZJQ. All rights reserved.
//


#define Content_Font  11
#define Content_Height  9
#define V_Margin   2
#define H_Margin   10
#define Content_Color   [UIColor whiteColor]

#import "DetailContentView.h"

#import "PatientModel.h"
#import "NSString+Ext.h"
#import "Tool.h"

@interface DetailContentView ()<ToolDelegate>

@property (nonatomic, strong) UILabel         *         nameLabel;
@property (nonatomic, strong) UILabel         *         sexLabel;
@property (nonatomic, strong) UILabel         *         ageLabel;
@property (nonatomic, strong) UILabel         *         typeLabel;
@property (nonatomic, strong) UILabel         *         numberLabel;
@property (nonatomic, strong) UILabel         *         dateLabel;

@property (nonatomic, strong) UILabel         *         winWidthLabel;
@property (nonatomic, strong) UILabel         *         winCenterLabel;
@property (nonatomic, strong) UILabel         *         noLabel;


@end

@implementation DetailContentView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [Tool shareInstance].delegate = self;
        
        [self addSubview:self.nameLabel];
        [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.left.top.offset(5);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.ageLabel];
        [self.ageLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.nameLabel);
            make.top.equalTo(self.nameLabel.mas_bottom).offset(V_Margin);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.sexLabel];
        [self.sexLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(self.nameLabel.mas_bottom).offset(V_Margin);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.typeLabel];
        [self.typeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.nameLabel);
            make.top.equalTo(self.ageLabel.mas_bottom).offset(V_Margin);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.numberLabel];
        [self.numberLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(self.ageLabel.mas_bottom).offset(V_Margin);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.dateLabel];
        [self.dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.nameLabel);
            make.top.equalTo(self.typeLabel.mas_bottom).offset(V_Margin);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.noLabel];
        [self.noLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.left.equalTo(self.nameLabel);
            make.top.equalTo(self.dateLabel.mas_bottom).offset(V_Margin);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.winCenterLabel];
        [self.winCenterLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.right.offset(-5);
            make.top.equalTo(self.nameLabel);
            make.height.offset(Content_Height);
        }];
        
        
        [self addSubview:self.winWidthLabel];
        [self.winWidthLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(self.nameLabel);
            make.height.offset(Content_Height);
        }];
        

        
        
        
    }
    return self;
}



#pragma mark - setter

- (void)setModel:(PatientModel *)model {

    self.nameLabel.text = model.name;
    [self.nameLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([model.name getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];
    
    self.ageLabel.text = model.age;
    [self.ageLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([model.age getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];
    
    self.sexLabel.text = model.sex;
    [self.sexLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.ageLabel.mas_right).offset(H_Margin);
        make.width.offset([model.sex getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];
    
    self.typeLabel.text = model.type;
    [self.typeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([model.age getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];
    
    self.numberLabel.text = model.number;
    [self.numberLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.typeLabel.mas_right).offset(H_Margin);
        make.width.offset([model.number getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];

    self.dateLabel.text = model.examineTime;
    [self.dateLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.offset([model.examineTime getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];

}

- (void)setWinWidthAndWinCenter:(NSMutableArray *)winWidthAndWinCenter {

    
    self.winCenterLabel.text = winWidthAndWinCenter[1];
    [self.winCenterLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        
        make.width.offset([winWidthAndWinCenter[1] getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];
    
    self.winWidthLabel.text = winWidthAndWinCenter[0];
    [self.winWidthLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        
        make.right.equalTo(self.winCenterLabel.mas_left).offset(-8);
        make.width.offset([winWidthAndWinCenter[0] getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];

    
}

- (void)setIndex:(NSString *)index {

    self.noLabel.text = index;
    [self.noLabel mas_updateConstraints:^(MASConstraintMaker *make) {
       
        make.width.offset([index getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];
    
}

#pragma mark - Tool Delegate

- (void)updateWinWidth:(NSString *)winWidth winCenter:(NSString *)winCenter{
    
    self.winCenterLabel.text = winCenter;
    [self.winCenterLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        
        make.width.offset([winCenter getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];
    
    self.winWidthLabel.text = winWidth;
    [self.winWidthLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        
        make.right.equalTo(self.winCenterLabel.mas_left).offset(-8);
        make.width.offset([winWidth getStringWidthWithHieght:Content_Height font:Content_Font]);
    }];

}

#pragma mark - lazy

- (UILabel *)nameLabel {
    
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont systemFontOfSize:Content_Font];
        _nameLabel.textColor = Content_Color;
    }
    return _nameLabel;
}
- (UILabel *)typeLabel {
    
    if (!_typeLabel) {
        _typeLabel = [UILabel new];
        _typeLabel.font = [UIFont boldSystemFontOfSize:Content_Font];
        _typeLabel.textColor = Content_Color;
    }
    return _typeLabel;
}
- (UILabel *)numberLabel {
    
    if (!_numberLabel) {
        _numberLabel = [UILabel new];
        _numberLabel.font = [UIFont systemFontOfSize:Content_Font];
        _numberLabel.textColor = Content_Color;
    }
    return _numberLabel;
}
- (UILabel *)ageLabel {
    
    if (!_ageLabel) {
        _ageLabel = [UILabel new];
        _ageLabel.font = [UIFont systemFontOfSize:Content_Font];
        _ageLabel.textColor = Content_Color;
    }
    return _ageLabel;
}
- (UILabel *)dateLabel {
    
    if (!_dateLabel) {
        _dateLabel = [UILabel new];
        _dateLabel.font = [UIFont systemFontOfSize:Content_Font];
        _dateLabel.textColor = Content_Color;
    }
    return _dateLabel;
}
- (UILabel *)sexLabel {
    
    if (!_sexLabel) {
        _sexLabel = [UILabel new];
        _sexLabel.font = [UIFont systemFontOfSize:Content_Font];
        _sexLabel.textColor = Content_Color;
    }
    return _sexLabel;
}
- (UILabel *)winWidthLabel {
    
    if (!_winWidthLabel) {
        _winWidthLabel = [UILabel new];
        _winWidthLabel.font = [UIFont systemFontOfSize:Content_Font];
        _winWidthLabel.textColor = Content_Color;
    }
    return _winWidthLabel;
}
- (UILabel *)winCenterLabel {
    
    if (!_winCenterLabel) {
        _winCenterLabel = [UILabel new];
        _winCenterLabel.font = [UIFont systemFontOfSize:Content_Font];
        _winCenterLabel.textColor = Content_Color;
    }
    return _winCenterLabel;
}
- (UILabel *)noLabel {
    
    if (!_noLabel) {
        _noLabel = [UILabel new];
        _noLabel.font = [UIFont systemFontOfSize:Content_Font];
        _noLabel.textColor = Content_Color;
    }
    return _noLabel;
}


@end
