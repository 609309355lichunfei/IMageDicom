//
//  DetailContentView.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/31.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PatientModel;

@interface DetailContentView : UIView


@property (nonatomic, strong) PatientModel           *            model;

/**将窗位和窗宽放到一个数组里穿了过来，这样是为了少写一个setter方法*/
@property (nonatomic, copy) NSArray<NSString *>      *            winWidthAndWinCenter;


/**当前影像文件是这一系列的第几张*/
@property (nonatomic, copy) NSString *  index;


@end
