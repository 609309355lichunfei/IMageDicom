//
//  DetailBottomView.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/31.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#define BTN_TAG  10
#define ANNOTATION_BTN_TAG  100

#define pi 3.14159265358979323846
#define RadiansToAngle(x) (180.0 * x / pi)

#import "DetailBottomView.h"
#import "KSDicom2DView.h"
#import "Tool.h"
#import "KSDicomDecoder.h"
#import "CanvasView.h"

@interface DetailBottomView ()

{

    CGAffineTransform                     _prevTransform;
    CGPoint                               _startPoint;
    UIPanGestureRecognizer          *     _panGesture;
    

}

@end

@implementation DetailBottomView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor lightGrayColor];
        
        self.isAnnotation = NO;
        [self setSubViewsWithIsAnnotation:self.isAnnotation];
    }
    return self;
}

#pragma mark - click
- (void)btnClicked:(UIButton *)sender {

    switch (sender.tag) {
        case BTN_TAG://顺时针旋转
            
            self.dicom2DView.transform = CGAffineTransformRotate(self.dicom2DView.transform, M_PI/2);
            break;
         
        case BTN_TAG+1://逆时针旋转
            
            self.dicom2DView.transform = CGAffineTransformRotate(self.dicom2DView.transform, -M_PI/2);
            break;
            
         
        case BTN_TAG+2://复位
            
            break;
         
        case BTN_TAG+3://标注
            
            
            self.isAnnotation = !self.isAnnotation;
            [self reload];
            [self.dicom2DView removeGestureRecognizer:_panGesture];
            break;
        
        default:
            break;
    }
}

- (void)annotationBtnClicked:(UIButton *)sender {

    for (UIButton *btn in self.subviews) {
        btn.selected = NO;
    }
    sender.selected = !sender.selected;
    switch (sender.tag) {
//        case ANNOTATION_BTN_TAG://测量
//            
//            
//            
//            break;
//            
//        case ANNOTATION_BTN_TAG+1://角度
//            
//            if (self.delegate && [self.delegate respondsToSelector:@selector(angle)]) {
//                [self.delegate angle];
//            }
//            
//            break;
//            
//        case ANNOTATION_BTN_TAG+2://矩形
//            
//            
//            break;
//            
//        case ANNOTATION_BTN_TAG+3://椭圆
//            
//            
//            break;
//            
//        case ANNOTATION_BTN_TAG+4://任意
//            
//            
//            break;
            
        case ANNOTATION_BTN_TAG+5://复位
            

            if (self.delegate && [self.delegate respondsToSelector:@selector(removeCanvasView)]) {
                [self.delegate removeCanvasView];
            }
            self.isAnnotation = !self.isAnnotation;
            [self reload];
            [self.dicom2DView addGestureRecognizer:_panGesture];
            break;
            
        default:
            
            if (self.delegate && [self.delegate respondsToSelector:@selector(mesureWithAnnotationType:)]) {
                [self.delegate mesureWithAnnotationType:sender.tag - ANNOTATION_BTN_TAG];
            }
            
            break;
    }
}

#pragma mark - setSubViews

- (void)reload{
    
    for (UIButton *btn in self.subviews) {
        [btn removeFromSuperview];
    }
    
    [self setSubViewsWithIsAnnotation:self.isAnnotation];
}



#pragma mark - setter
- (void)setIsAnnotation:(BOOL)isAnnotation {

    _isAnnotation = isAnnotation;
}

- (void)setDicom2DView:(KSDicom2DView *)dicom2DView {

    _dicom2DView = dicom2DView;
    
    
    _panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    _panGesture.maximumNumberOfTouches = 1;
    [self.dicom2DView addGestureRecognizer:_panGesture];
    
    
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(handlePinchGesture:)];
    [self.dicom2DView addGestureRecognizer:pinchGesture];
    
    // 旋转手势
    UIRotationGestureRecognizer *rotationGestureRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(handleRotationGesture:)];
    [self.dicom2DView addGestureRecognizer:rotationGestureRecognizer];
}

- (void)setSubViewsWithIsAnnotation:(BOOL)isAnnotation {

    if (isAnnotation) {
        
        for (int i=0; i<6; i++) {
            
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(i*MedFilm_WIDTH/6, 0, MedFilm_WIDTH/6, self.frame.size.height);
            [btn setTitle:@[@"测量",@"角度",@"矩形",@"椭圆",@"任意",@"复位"][i] forState:UIControlStateNormal];
            btn.titleLabel.font = [UIFont systemFontOfSize:15];
            btn.tag = ANNOTATION_BTN_TAG + i;
            [btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
            [btn addTarget:self action:@selector(annotationBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btn];
        }
        
    } else {
        
        for (int i=0; i<4; i++) {
            
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(i*MedFilm_WIDTH/4, 0, MedFilm_WIDTH/4, self.frame.size.height);
            [btn setTitle:@[@"顺时针旋转",@"逆时针旋转",@"复位",@"标注"][i] forState:UIControlStateNormal];
            btn.titleLabel.font = [UIFont systemFontOfSize:15];
            btn.tag = BTN_TAG + i;
            [btn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:btn];
        }
    }
}


#pragma mark - 捏合手势
- (void)handlePinchGesture:(UIPinchGestureRecognizer *)sender {
    
    UIView *view = sender.view;
    if (sender.state == UIGestureRecognizerStateBegan || sender.state == UIGestureRecognizerStateChanged) {
        view.transform = CGAffineTransformScale(view.transform, sender.scale, sender.scale);
        
        sender.scale = 1;
    }
}

#pragma mark - 旋转手势
- (void) handleRotationGesture:(UIRotationGestureRecognizer *)rotationGestureRecognizer
{
    UIView *view = rotationGestureRecognizer.view;
    if (rotationGestureRecognizer.state == UIGestureRecognizerStateBegan || rotationGestureRecognizer.state == UIGestureRecognizerStateChanged) {
        view.transform = CGAffineTransformRotate(view.transform, rotationGestureRecognizer.rotation);
        
        [rotationGestureRecognizer setRotation:0];
    }
}


#pragma mark - 拖动手势

-(void) handlePanGesture:(UIPanGestureRecognizer *) sender
{
    
    UIGestureRecognizerState state = [sender state];
    
    if (state == UIGestureRecognizerStateBegan)
    {
        _prevTransform = self.dicom2DView.transform;
        _startPoint = [sender locationInView:self.dicom2DView];
    }
    else if (state == UIGestureRecognizerStateChanged || state == UIGestureRecognizerStateEnded)
    {
        
        CGPoint location    = [sender locationInView:self.dicom2DView];
        CGFloat offsetX     = location.x - _startPoint.x;
        CGFloat offsetY     = location.y - _startPoint.y;
        _startPoint          = location;
        
#if 0
        // translate
        //
        CGAffineTransform translate = CGAffineTransformMakeTranslation(offsetX, offsetY);
        dicom2DView.transform  = CGAffineTransformConcat(prevTransform, translate);
#else
        // adjust window width/level
        //
        self.dicom2DView.winWidth  += offsetX * self.dicom2DView.changeValWidth;
        self.dicom2DView.winCenter += offsetY * self.dicom2DView.changeValCentre;
        
        if (self.dicom2DView.winWidth <= 0) {
            self.dicom2DView.winWidth = 1;
        }
        
        if (self.dicom2DView.winCenter == 0) {
            self.dicom2DView.winCenter = 1;
        }
        
        if (self.dicom2DView.signed16Image) {
            self.dicom2DView.winCenter += SHRT_MIN;
        }
        
        [self.dicom2DView setWinWidth:self.dicom2DView.winWidth];
        [self.dicom2DView setWinCenter:self.dicom2DView.winCenter];
        
        [[Tool shareInstance]displayWith:self.dicom2DView.winWidth windowCenter:self.dicom2DView.winCenter dicomDecoder:self.dicomDecoder dicom2DView:self.dicom2DView];
#endif
    }
    
}


@end
