//
//  PatientModel.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PatientModel : NSObject


@property (nonatomic, copy) NSString *  name;//患者姓名
@property (nonatomic, copy) NSString *  type;//影像类型，比如CT,DX,US等
@property (nonatomic, copy) NSString *  age;//患者年龄
@property (nonatomic, copy) NSString *  number;//影像编号
@property (nonatomic, copy) NSString *  sex;//患者性别
@property (nonatomic, copy) NSString *  examineTime;//检查时间
@property (nonatomic, copy) NSString *  part;//影像展示的部位
@property (nonatomic, copy) NSString *  StudyUniqueId;//id
@property (nonatomic, copy) NSString *  yiyuan;//检查时间




@end
