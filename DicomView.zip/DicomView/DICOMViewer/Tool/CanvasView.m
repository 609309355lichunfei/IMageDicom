//
//  CanvasView.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/4/7.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

static CFTimeInterval const kDuration = 2.0;
static CGFloat const kDistanceThreshold = 10.0;
static CGFloat const kPointDiameter = 7.0;

#import "CanvasView.h"

#import "ShapeView.h"

@interface CanvasView ()

{

    AnnotationType                   _annotationType;

}

//@property (nonatomic, strong) NSMutableArray           *        startPointArray;
//@property (nonatomic, strong) NSMutableArray           *        endPointArray;
@property (nonatomic) NSUInteger                                indexOfSelectedPoint;
@property (nonatomic) CGVector                                  touchOffsetForSelectedPoint;
@property (nonatomic, strong) NSMutableArray           *        points;
@property (nonatomic, strong) NSValue                  *        prospectivePointValue;
@property (nonatomic, strong) NSTimer                  *        pressTimer;
@property (nonatomic, assign) BOOL                              ignoreTouchEvents;

@end

@implementation CanvasView


- (instancetype)initWithFrame:(CGRect)frame withAnnotationType:(AnnotationType)annotationType
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor clearColor];
        
        _points = [[NSMutableArray alloc] init];
        self.multipleTouchEnabled = NO;
        
        //标注类型
        _annotationType = annotationType;
        
        _ignoreTouchEvents = NO;
        _indexOfSelectedPoint = NSNotFound;
        
        _pathShapeView = [[ShapeView alloc] init];
        _pathShapeView.shapeLayer.fillColor = nil;
        _pathShapeView.backgroundColor = [UIColor clearColor];
        _pathShapeView.opaque = NO;
        _pathShapeView.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_pathShapeView];
        
        _prospectivePathShapeView = [[ShapeView alloc] init];
        _prospectivePathShapeView.shapeLayer.fillColor = nil;
        _prospectivePathShapeView.backgroundColor = [UIColor clearColor];
        _prospectivePathShapeView.opaque = NO;
        _prospectivePathShapeView.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_prospectivePathShapeView];
        
        _pointsShapeView = [[ShapeView alloc] init];
        _pointsShapeView.backgroundColor = [UIColor clearColor];
        _pointsShapeView.opaque = NO;
        _pointsShapeView.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_pointsShapeView];
        
        NSDictionary *views = NSDictionaryOfVariableBindings(_pathShapeView, _prospectivePathShapeView, _pointsShapeView);
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_pathShapeView]|" options:0 metrics:nil views:views]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_prospectivePathShapeView]|" options:0 metrics:nil views:views]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_pointsShapeView]|" options:0 metrics:nil views:views]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[_pathShapeView]|" options:0 metrics:nil views:views]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[_prospectivePathShapeView]|" options:0 metrics:nil views:views]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[_pointsShapeView]|" options:0 metrics:nil views:views]];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {

    [self drawPath];
}
- (void)tintColorDidChange
{
    [super tintColorDidChange];
    
    self.pointsShapeView.shapeLayer.fillColor = self.tintColor.CGColor;
}
#pragma mark - touch
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

    if (self.ignoreTouchEvents) {
        return;
    }
    
    NSValue *pointValue = [self pointValueWithTouches:touches];
    
    NSIndexSet *indexes = [self.points indexesOfObjectsPassingTest:^BOOL(NSValue *existingPointValue, NSUInteger idx, BOOL *stop) {
        CGPoint point = [pointValue CGPointValue];
        CGPoint existingPoint = [existingPointValue CGPointValue];
        CGFloat distance = ABS(point.x - existingPoint.x) + ABS(point.y - existingPoint.y);
        return distance < kDistanceThreshold;
    }];
    
    if ([indexes count] > 0) {
        self.indexOfSelectedPoint = [indexes lastIndex];
        
        NSValue *existingPointValue = [self.points objectAtIndex:self.indexOfSelectedPoint];
        CGPoint point = [pointValue CGPointValue];
        CGPoint existingPoint = [existingPointValue CGPointValue];
        self.touchOffsetForSelectedPoint = CGVectorMake(point.x - existingPoint.x, point.y - existingPoint.y);
        
        self.pressTimer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                                           target:self
                                                         selector:@selector(pressTimerFired:)
                                                         userInfo:nil
                                                          repeats:NO];
    }
    else {
        self.prospectivePointValue = pointValue;
    }
    
    [self updatePaths];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

    if (self.ignoreTouchEvents) {
        return;
    }
    
    [self.pressTimer invalidate];
    self.pressTimer = nil;
    
    NSValue *pointValue = [self pointValueWithTouches:touches];
    
    if (self.indexOfSelectedPoint != NSNotFound) {
        NSValue *offsetPointValue = [self pointValueByRemovingOffset:self.touchOffsetForSelectedPoint fromPointValue:pointValue];
        [self.points replaceObjectAtIndex:self.indexOfSelectedPoint withObject:offsetPointValue];
    }
    else {
        self.prospectivePointValue = pointValue;
    }
    
    [self updatePaths];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

    if (self.ignoreTouchEvents) {
        self.ignoreTouchEvents = NO;
        return;
    }
    
    [self.pressTimer invalidate];
    self.pressTimer = nil;
    
    NSValue *pointValue = [self pointValueWithTouches:touches];
    
    if (self.indexOfSelectedPoint != NSNotFound) {
        NSValue *offsetPointValue = [self pointValueByRemovingOffset:self.touchOffsetForSelectedPoint fromPointValue:pointValue];
        [self.points replaceObjectAtIndex:self.indexOfSelectedPoint withObject:offsetPointValue];
        self.indexOfSelectedPoint = NSNotFound;
    }
    else {
        [self.points addObject:pointValue];
        self.prospectivePointValue = nil;
    }
    
    [self updatePaths];
    
   
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

    if (self.ignoreTouchEvents) {
        self.ignoreTouchEvents = NO;
        return;
    }
    
    [self.pressTimer invalidate];
    self.pressTimer = nil;
    
    self.indexOfSelectedPoint = NSNotFound;
    self.prospectivePointValue = nil;
    [self updatePaths];
}


#pragma mark - Action Methods

- (void)pressTimerFired:(NSTimer *)timer
{
    [self.pressTimer invalidate];
    self.pressTimer = nil;
    
    [self.points removeObjectAtIndex:self.indexOfSelectedPoint];
    self.indexOfSelectedPoint = NSNotFound;
    self.ignoreTouchEvents = YES;
    
    [self updatePaths];
}


#pragma mark - private
- (NSValue *)pointValueWithTouches:(NSSet *)touches
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    return [NSValue valueWithCGPoint:point];
}

- (NSValue *)pointValueByRemovingOffset:(CGVector)offset fromPointValue:(NSValue *)pointValue
{
    CGPoint point = [pointValue CGPointValue];
    CGPoint offsetPoint = CGPointMake(point.x - offset.dx, point.y - offset.dy);
    return [NSValue valueWithCGPoint:offsetPoint];
}


- (void)updatePaths {

    {
        UIBezierPath *path = [[UIBezierPath alloc] init];
        for (NSValue *pointValue in self.points) {
            CGPoint point = [pointValue CGPointValue];
            [path appendPath:[UIBezierPath bezierPathWithArcCenter:point radius:kPointDiameter / 2.0 startAngle:0.0 endAngle:2 * M_PI clockwise:YES]];
        }
        self.pointsShapeView.shapeLayer.path = path.CGPath;
    }
    
    if ([self.points count] >= 2) {
        UIBezierPath *path = [[UIBezierPath alloc] init];
        [path moveToPoint:[[self.points firstObject] CGPointValue]];
        
        NSIndexSet *indexSet = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(1, [self.points count] - 1)];
        [self.points enumerateObjectsAtIndexes:indexSet
                                       options:0
                                    usingBlock:^(NSValue *pointValue, NSUInteger idx, BOOL *stop) {
                                        [path addLineToPoint:[pointValue CGPointValue]];
                                    }];
        
        self.pathShapeView.shapeLayer.path = path.CGPath;
    }
    else {
        self.pathShapeView.shapeLayer.path = nil;
    }
    
    if ([self.points count] >= 1 && self.prospectivePointValue) {
        UIBezierPath *path = [[UIBezierPath alloc] init];
        [path moveToPoint:[[self.points lastObject] CGPointValue]];
        [path addLineToPoint:[self.prospectivePointValue CGPointValue]];
        
        self.prospectivePathShapeView.shapeLayer.path = path.CGPath;
    }
    else {
        self.prospectivePathShapeView.shapeLayer.path = nil;
    }
    
}

- (void)drawPath {

    CFTimeInterval timeOffset = self.pathShapeView.shapeLayer.timeOffset;
    [CATransaction setCompletionBlock:^{
        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:NSStringFromSelector(@selector(strokeEnd))];
        animation.fromValue = @0.0;
        animation.toValue = @1.0;
        animation.removedOnCompletion = NO;
        animation.duration = kDuration;
        self.pathShapeView.shapeLayer.speed = 0;
        self.pathShapeView.shapeLayer.timeOffset = 0;
        [self.pathShapeView.shapeLayer addAnimation:animation forKey:NSStringFromSelector(@selector(strokeEnd))];
        [CATransaction flush];
        self.pathShapeView.shapeLayer.timeOffset = timeOffset;
    }];
    
    self.pathShapeView.shapeLayer.timeOffset = 0.0;
    self.pathShapeView.shapeLayer.speed = 1.0;
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:NSStringFromSelector(@selector(strokeEnd))];
    animation.fromValue = @0.0;
    animation.toValue = @1.0;
    animation.duration = kDuration;
    
    [self.pathShapeView.shapeLayer addAnimation:animation forKey:NSStringFromSelector(@selector(strokeEnd))];

}

#pragma mark - setter
//- (NSMutableArray *)startPointArray {
//    
//    if (!_startPointArray) {
//        _startPointArray = [NSMutableArray array];
//    }
//    return _startPointArray;
//}
//
//- (NSMutableArray *)endPointArray {
//    
//    if (!_endPointArray) {
//        _endPointArray = [NSMutableArray array];
//    }
//    return _endPointArray;
//}



@end
