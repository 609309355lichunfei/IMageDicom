//
//  ShapeView.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/4/11.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

@import UIKit;



@interface ShapeView : UIView

@property (nonatomic, strong) CAShapeLayer *shapeLayer;


@end
