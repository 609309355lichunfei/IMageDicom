//
//  Tool.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/29.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@protocol ToolDelegate <NSObject>

//这个代理的作用是：滑动影像时，将不断改变的窗位和窗宽传给DetailContentView,进而显示在label上
- (void)updateWinWidth:(NSString *)winWidth winCenter:(NSString *)winCenter;

@end

@class KSDicom2DView,KSDicomDecoder;
@interface Tool : NSObject


@property (nonatomic, weak) id <ToolDelegate>  delegate;

/**
 单例

 @return <#return value description#>
 */
+ (Tool *)shareInstance;



/**
 计算角度

 @param startPoint 起点，，也就是两条线的交点
 @param endPoint 第一条线的终点
 @param secEndPoint 第二条线的终点
 @return 角度值
 */
-(CGFloat)angleForStartPoint:(CGPoint)startPoint firstEndPoint:(CGPoint)endPoint secEndPoint:(CGPoint)secEndPoint;



/**
 解析dicom文件

 @param path 文件路径
 @param dicomDecoder <#dicomDecoder description#>
 @param dicom2DView <#dicom2DView description#>
 */
- (void) decodeAndDisplay:(NSString *)path dicomDecoder:(KSDicomDecoder *)dicomDecoder dicom2DView:(KSDicom2DView *)dicom2DView;

- (void) displayWith:(NSInteger)windowWidth windowCenter:(NSInteger)windowCenter dicomDecoder:(KSDicomDecoder *)dicomDecoder dicom2DView:(KSDicom2DView *)dicom2DView;

@end
