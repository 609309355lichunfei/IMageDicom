//
//  NSString+Ext.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Ext)



/**
 判断是否为空

 @return <#return value description#>
 */
- (BOOL)isNull;



/**
 获取字符串高度

 @param width 字符串宽度
 @param font 字体大小
 @return <#return value description#>
 */
- (CGFloat)getStringHeightWithWidth:(CGFloat)width font:(CGFloat)font;



/**
 获取字符串宽度

 @param height 字符串高度
 @param font 字体大小
 @return <#return value description#>
 */
- (CGFloat)getStringWidthWithHieght:(CGFloat)height font:(CGFloat)font;

@end
