//
//  CanvasView.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/4/7.
//  Copyright © 2017年 ZJQ. All rights reserved.
//


typedef NS_ENUM(NSInteger,AnnotationType){
    
    AnnotationLine = 0,
    AnnotationAngle = 1,
    AnnotationRect = 2,
    AnnotationOval = 3,
    AnnotationAny = 4,
};

#import <UIKit/UIKit.h>

#import <QuartzCore/QuartzCore.h>
#define PI 3.14159265358979323846

@class ShapeView;
@interface CanvasView : UIView

@property (nonatomic, strong, readonly) ShapeView    *    pointsShapeView;
@property (nonatomic, strong, readonly) ShapeView    *    pathShapeView;
@property (nonatomic, strong, readonly) ShapeView    *    prospectivePathShapeView;


- (instancetype)initWithFrame:(CGRect)frame withAnnotationType:(AnnotationType)annotationType;


@end
