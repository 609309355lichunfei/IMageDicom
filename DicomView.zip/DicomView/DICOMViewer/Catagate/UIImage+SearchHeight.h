//
//  UIImage+SearchHeight.h
//  LCFDeerShop
//
//  Created by 李春菲 on 16/11/21.
//  Copyright © 2016年 lichunfei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (SearchHeight)
+(UIImage *) GetImageWithColor:(UIColor *)color addHeight:(CGFloat )height;
@end
