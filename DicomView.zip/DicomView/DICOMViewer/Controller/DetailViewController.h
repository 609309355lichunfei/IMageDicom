//
//  DetailViewController.h
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

#import <UIKit/UIKit.h>






@class PatientModel;
@interface DetailViewController : UIViewController


@property (nonatomic, copy) NSString                 *            path;
@property (nonatomic, copy) NSString                 *            path1;
@property (nonatomic, copy) NSMutableArray                 *            PathArray;

@property (nonatomic, strong) PatientModel           *            model;

@end
