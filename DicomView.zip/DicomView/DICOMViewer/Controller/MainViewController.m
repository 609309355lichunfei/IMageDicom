//
//  MainViewController.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
#import "MainViewController.h"
#import "KSDicomDecoder.h"
#import "PatientModel.h"
#import "YYModel.h"
#import "MainCell.h"
#import "DetailViewController.h"
#import "jindutiao.h"
#import "PPHTTPRequest.h"
#import "GCLoadingView.h"
#import "GCLoadingLayer.h"
#import "MJRefresh.h"
#import "jindutiao.h"
#define GCLoadingLayerCenterX MedFilm_WIDTH/2
#define GCLoadingLayerCenterY MedFilm_HEIGHT/2
@interface MainViewController ()<UITableViewDelegate,UITableViewDataSource>

{

    KSDicomDecoder *dicomDecoder;

}

@property (nonatomic ,strong) UITableView         *   tableView;
@property (nonatomic, strong) NSMutableArray      *   dataArray;//储存model数组
@property (nonatomic, strong) NSMutableArray      *   pathArray;//储存路径数组
@property (nonatomic, strong) NSMutableArray      *   dataArrayarr;//储存所有连接数据
@property (nonatomic,copy)    NSString            *   urlStar;//用来储存连接数据
@property (strong, nonatomic) UIProgressView      *   progress;
@property (nonatomic,copy)    NSString            *   InstanceNumber;//影像编号
@property (nonatomic,copy)    NSString            *   filepath;
@end

@implementation MainViewController

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
}

-(void)viewDidDisappear:(BOOL)animated {
    
    [super viewDidDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];

     [self.view addSubview:self.tableView];
    // 开启日志打印
    [PPNetworkHelper openLog];

  //  [self PPHTTPRequestLayer];
     [self addRefreshHeader];  //下拉刷新
   
}
- (void)addRefreshHeader{
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        __weak typeof (self) weakSelf = self;
     
        [weakSelf PPHTTPRequestLayer];
    }];
       [self.tableView.mj_header beginRefreshing];
}


#pragma mark  网络请求

- (void)PPHTTPRequestLayer {
    __weak typeof (self) weakSelf = self;
    
 
    [PPHTTPRequest getLoginWithParameters:@{@"hid":@"41952984-3",@"no":@"ZX-1481199",@"mo":@"CT"} success:^(id response) {
        weakSelf.dataArrayarr = [response valueForKey:@"SeriesList"];
        //清空所有数组 防止多余增加
          [self.dataArray removeAllObjects];
        for (NSDictionary * dic in weakSelf.dataArrayarr) {
            
              NSArray * array = [dic valueForKey:@"ImageList"];
            
            for (NSDictionary * dicdata in array) {
                
                NSString * str = [dicdata valueForKey:@"ImagePath"];
                
               self.urlStar = [NSString strGetToHttp:str];
               
               self.InstanceNumber = [dicdata valueForKey:@"InstanceNumber"];
                
                [weakSelf downLoad:response[@"StudyUniqueId"]];
              
               
            }
        }
        //如果放在外面 列表显示一个
        NSDictionary *dic11111 = @{@"name":[response valueForKey:@"PatientName"],
                                   @"StudyUniqueId":response[@"StudyUniqueId"],
                                   @"sex":response[@"PatientSex"],
                                   @"examineTime":response[@"StudyDateTime"],
                                   @"part":response[@"BodyPartExamined"],
                                   @"type":response[@"ModalitiesInStudy"],
                                   @"number":self.InstanceNumber
                                   
                                   };
        PatientModel *patientModel = [PatientModel yy_modelWithDictionary:dic11111];
        
        [self.dataArray addObject:patientModel];
    
       
     [weakSelf.tableView.mj_header endRefreshing];
    
    } failure:^(NSError *error) {
     
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"网络错误请检查网络"
                                                            message:@""
                                                           delegate:nil
                                                  cancelButtonTitle:@"确定"
                                                  otherButtonTitles:nil];
        [alertView show];
        [weakSelf.tableView.mj_header endRefreshing];
    }];
}
-(void)downLoad:(NSString *)ididid {
      static NSURLSessionTask *task = nil;
    __weak typeof (self) weakSelf = self;
    //判断是否有文件夹存在 如果有就停止下载文件节省时间.  如果没有文件就加载文件
    if (![weakSelf isFileExist:ididid]) {

        task = [PPNetworkHelper downloadWithURL:self.urlStar fileDir:ididid progress:^(NSProgress *progress) {

        } success:^(NSString *filePath) {
           
            NSString  * cacheFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
            
            NSString * path = [cacheFolder stringByAppendingPathComponent:[ididid stringByAppendingPathComponent:[filePath lastPathComponent]]];
            
            dicomDecoder = [[KSDicomDecoder alloc] init];
            
            [dicomDecoder setDicomFilename:path];
            
            [weakSelf.pathArray addObject:path];
            
            [weakSelf.tableView reloadData];
            
            PPLog(@"filePath = %@",filePath);
            
            self.filepath = filePath;
            
        } failure:^(NSError *error) {

            PPLog(@"error = %@",error);
        }];
    }else {
        
        [task suspend]; 
        NSLog(@"停止下载");
    }
}
#pragma mark - 一次性获取当前最新网络状态
- (void)getCurrentNetworkStatus
{
    if (kIsNetwork) {
        PPLog(@"有网络");
        if (kIsWWANNetwork) {
            PPLog(@"手机网络");
        }else if (kIsWiFiNetwork){
            PPLog(@"WiFi网络");
        }
    } else {
        PPLog(@"无网络");
    }
    
}
//判断文件是否已经在沙盒中已经存在？
-(BOOL) isFileExist:(NSString *)fileName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *filePath = [path stringByAppendingPathComponent:fileName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL result = [fileManager fileExistsAtPath:filePath];
    //NSLog(@"这个文件已经存在：%@",result?@"是的":@"不存在");
    return result;
}
#pragma mark - tableView delegate / dataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellID = @"cell";
    MainCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[MainCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    cell.model = self.dataArray[indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    return 90;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [tableView deselectRowAtIndexPath:indexPath animated:true];
    

    DetailViewController *detail = [[DetailViewController alloc]init];
    
     PatientModel *patientModel = self.dataArray[indexPath.row];
    
    NSString *path = patientModel.StudyUniqueId;
    
    detail.path = path;
    
    detail.path1 = self.filepath;
    
    detail.model = self.dataArray[indexPath.row];
    
    detail.PathArray = self.pathArray;
    [self.navigationController pushViewController:detail animated:true];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 从数据源中删除
    [self.dataArray removeObjectAtIndex:indexPath.row];
    // 从列表中删除
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
}


#pragma mark - lazy
- (UITableView *)tableView{
    
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64-48) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.automaticallyAdjustsScrollViewInsets= NO;
    }
    return _tableView;
}

#pragma  mark  初始化

- (NSMutableArray *)dataArray{
    
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSMutableArray *)pathArray{
    
    if (!_pathArray) {
        _pathArray = [NSMutableArray array];
    }
    return _pathArray;
}
- (NSMutableArray *)dataArrayarr{
    
    if (!_dataArrayarr) {
        _dataArrayarr = [NSMutableArray array];
    }
    return _dataArrayarr;
}

- (UIProgressView *)progress {
    
    if (!_progress) {
        _progress = [[UIProgressView alloc]initWithFrame:CGRectMakeAdapt(0, 0, MedFilm_WIDTH, 20)];
    }
     return   _progress;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
