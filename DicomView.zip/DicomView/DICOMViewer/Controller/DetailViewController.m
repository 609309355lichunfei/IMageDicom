//
//  DetailViewController.m
//  DICOMViewer
//
//  Created by ZJQ on 2017/3/30.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

static CFTimeInterval const kDuration = 2.0;
static CFTimeInterval const kInitialTimeOffset = 2.0;

#import "DetailViewController.h"

#import "KSDicom2DView.h"
#import "KSDicomDecoder.h"

#import "DetailContentView.h"
#import "PatientModel.h"
#import "Tool.h"
#import "DetailBottomView.h"
#import "CustomSlider.h"

#import "CanvasView.h"

#import "ShapeView.h"

@interface DetailViewController ()<CustomSliderDelegate,DetailBottomViewDelegate>

@property (nonatomic, strong) KSDicom2DView       *      dicom2DView;
@property (nonatomic, strong) KSDicomDecoder      *      dicomDecoder;
@property (nonatomic, strong) DetailContentView   *      detailContentView;
@property (nonatomic, strong) DetailBottomView    *      detailBottomView;
@property (nonatomic, strong) CustomSlider        *      slider;
@property (nonatomic, strong) CanvasView          *      canvasView;
@property (nonatomic, strong) NSString          *      strPath;
@property (nonatomic,strong)  NSTimer          *      dicomTimer;
@property  (nonatomic,assign) BOOL           isPlay1;
@end

@implementation DetailViewController

#pragma mark - life cycle 
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor blackColor];
    NSLog(@"%@++++++++++++++++++++2",self.PathArray);
    
//    for (NSString * str in self.PathArray) {
//        self.strPath = str;
//       
//        
//    }
     [self setSubViews];
//    
//    UIButton * bt  =   [UIButton buttonWithType:UIButtonTypeCustom];
//    
//    bt.frame = CGRectMake(200, 200, 200, 200);
//    bt.backgroundColor = [UIColor redColor];
//    [bt addTarget:self action:@selector(actionsele) forControlEvents:UIControlEventTouchUpInside];
//    
//    [self.view addSubview:bt];
    
}

- (void)actionsele {
   
    if (self.dicomTimer == nil) {
        self.dicomTimer = [NSTimer timerWithTimeInterval:1 repeats:YES block:^(NSTimer * _Nonnull timer) {
            [self changeDicom];
        }];
       
        [[NSRunLoop currentRunLoop] addTimer:_dicomTimer forMode:NSRunLoopCommonModes];
        _isPlay1 = YES;
    }else{
        
        if (_isPlay1) {
            [self.dicomTimer setFireDate:[NSDate distantFuture]];
            _isPlay1 = NO;
        }
    }
    
}
- (void)changeDicom {
    

}
#pragma mark - subViews 
- (void)setSubViews {

    
    [self.view addSubview:self.dicom2DView];
    [self.view addSubview:self.detailContentView];
    [self.view addSubview:self.detailBottomView];
    [self.view addSubview:self.slider];

    NSString  * cacheFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    
    NSString * path = [cacheFolder stringByAppendingPathComponent:[self.path stringByAppendingPathComponent:[self.path1 lastPathComponent]]];
    
    
//    NSString  * cacheFolder = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
//    
//    NSString * path = [cacheFolder stringByAppendingPathComponent:[self.path stringByAppendingPathComponent:[self.strPath lastPathComponent]]];
    
    [self.dicomDecoder setDicomFilename:path];
    [[Tool shareInstance]decodeAndDisplay:path dicomDecoder:self.dicomDecoder dicom2DView:self.dicom2DView];
    self.detailContentView.model = self.model;
    self.detailContentView.winWidthAndWinCenter = @[[NSString stringWithFormat:@"窗宽:%ld",(long)self.dicom2DView.winWidth],[NSString stringWithFormat:@"窗位:%ld",(long)self.dicom2DView.winCenter]];
    //self.detailContentView.index = [NSString stringWithFormat:@"No:%d/7",1];
    self.detailBottomView.dicom2DView = self.dicom2DView;
    self.detailBottomView.dicomDecoder = self.dicomDecoder;
    
}

#pragma mark - CustomSliderDelegate
- (void)slider:(CustomSlider *)slider didScrollValue:(CGFloat)value {

    int index = value/(100/6);
   
    NSString *path = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%d",index] ofType:@"dcm"];
  
    self.path = path;
    [_dicomDecoder setDicomFilename:self.path];
    [[Tool shareInstance]decodeAndDisplay:self.path dicomDecoder:self.dicomDecoder dicom2DView:self.dicom2DView];
    
    self.detailContentView.index = [NSString stringWithFormat:@"No:%d/7",index+1];
}

#pragma mark - lazy
- (DetailContentView *)detailContentView {

    if (!_detailContentView) {
        _detailContentView = [[DetailContentView alloc]initWithFrame:CGRectMake(0, 64, MedFilm_WIDTH, 80)];
        
    }
    return _detailContentView;
}

- (KSDicom2DView *)dicom2DView {

    if (!_dicom2DView) {
        _dicom2DView = [[KSDicom2DView alloc]initWithFrame:CGRectMake(40, 100, MedFilm_WIDTH-40*2, MedFilm_WIDTH-40*2)];
        _dicom2DView.backgroundColor = [UIColor blackColor];
    }
    return _dicom2DView;
}
- (KSDicomDecoder *)dicomDecoder {

    if (!_dicomDecoder) {
        _dicomDecoder = [[KSDicomDecoder alloc]init];
        
    }
    return _dicomDecoder;
}

- (DetailBottomView *)detailBottomView {

    if (!_detailBottomView) {
        _detailBottomView = [[DetailBottomView alloc]initWithFrame:CGRectMake(0, MedFilm_HEIGHT-40, MedFilm_WIDTH, 40)];
        _detailBottomView.delegate = self;
    }
    return _detailBottomView;
}

- (CustomSlider *)slider {

    if (!_slider) {
        
        _slider = [[CustomSlider alloc]initWithFrame:CGRectMake(20, MedFilm_HEIGHT-60, self.view.frame.size.width - 40, 10)];
        _slider.currentValueColor = [UIColor greenColor];
        _slider.maxValue = 100;
        _slider.currentSliderValue = 0;
        _slider.showTouchView = YES;
        _slider.showTextColor = [UIColor greenColor];
        _slider.touchViewColor = [UIColor lightGrayColor];
        _slider.delegate = self;
    }
    return _slider;
}

- (void)canvasViewWithType:(AnnotationType)type {

    _canvasView = [[CanvasView alloc]initWithFrame:self.dicom2DView.bounds withAnnotationType:type];

    _canvasView.pointsShapeView.shapeLayer.strokeColor = [UIColor greenColor].CGColor;
    _canvasView.pathShapeView.shapeLayer.strokeColor = [UIColor orangeColor].CGColor;
    _canvasView.prospectivePathShapeView.shapeLayer.strokeColor = [UIColor grayColor].CGColor;
    
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:NSStringFromSelector(@selector(strokeEnd))];
    animation.fromValue = @0.0;
    animation.toValue = @1.0;
    animation.removedOnCompletion = NO;
    animation.duration = kDuration;
    [_canvasView.pathShapeView.shapeLayer addAnimation:animation forKey:NSStringFromSelector(@selector(strokeEnd))];
    
    _canvasView.pathShapeView.shapeLayer.speed = 0;
    _canvasView.pathShapeView.shapeLayer.timeOffset = 0.0;
    
    [CATransaction flush];
    
    _canvasView.pathShapeView.shapeLayer.timeOffset = kInitialTimeOffset;
    [self.dicom2DView addSubview:_canvasView];
    
}

#pragma mark - DetailBottomViewDelegate



- (void)mesureWithAnnotationType:(NSInteger)annotationType{

//    if (_canvasView) {
//        [self removeCanvasView];
//    }
    [self canvasViewWithType:AnnotationLine];
}

- (void)removeCanvasView{

    [self.canvasView removeFromSuperview];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
